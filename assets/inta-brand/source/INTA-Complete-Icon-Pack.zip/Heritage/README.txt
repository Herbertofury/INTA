INTA Heritage icon pack

Detailed heritage artwork for branding, About screens, launchers and large-format display. For tiny taskbar icons and favicons, prefer the Application edition.

ICO: multi-resolution, 32-bit alpha PNG frames at 16, 20, 24, 32, 40, 48, 64, 72, 96, 128, 256 px. Intended for modern Windows.
PNG: transparent square icons at 16, 20, 24, 32, 40, 48, 64, 72, 96, 128, 144, 152, 180, 192, 256, 384, 512, 768, 1024 px.
Native PNG: original cleaned artwork, cropped to the emblem bounds, without resampling.
The source emblem is preserved, with no generated imagery, added border or recoloring. Isolated transparency speckles were removed, near-opaque alpha was normalized, and the original proportions were preserved. Square icons use approximately 4% horizontal clear space per side (minimum 1 px) and a slight optical lift at larger sizes.
